# train_model.py
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers
import os
import cv2

def load_dataset(data_path):
    """Load depth images and corresponding distances from saved dataset."""
    depth_files = [f for f in os.listdir(data_path) if f.startswith('d_') and f.endswith('.npy')]
    X = []
    y = []

    for d_file in depth_files:
        # Load depth map (saved as .npy)
        depth_data = np.load(os.path.join(data_path, d_file))
        
        # Normalize depth to [0, 1] range
        depth_normalized = (depth_data - depth_data.min()) / (depth_data.max() - depth_data.min())
        X.append(depth_normalized)
        
        # Extract distance from filename or metadata (example)
        # You may need to modify this based on how you store labels
        distance = float(d_file.split('_')[1].replace('.npy', ''))  # Placeholder
        y.append(distance)
    
    return np.array(X), np.array(y)

def create_model(input_shape=(480, 640, 1)):
    """Define the CNN model for distance prediction."""
    model = tf.keras.Sequential([
        layers.Input(shape=input_shape),
        layers.Conv2D(32, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.Flatten(),
        layers.Dense(128, activation='relu'),
        layers.Dense(1)  # Regression output (distance)
    ])
    
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model

def train():
    data_path = "training_data/"
    X, y = load_dataset(data_path)
    
    # Reshape for CNN (add channel dimension if grayscale)
    X = X[..., np.newaxis]  # Shape: (N, H, W, 1)
    
    # Split into train/test
    split = int(0.8 * len(X))
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]
    
    # Create and train model
    model = create_model()
    model.fit(X_train, y_train, epochs=10, validation_data=(X_test, y_test))
    
    # Save model for later use in main app
    model.save("ml_models/obstacle_detector.h5")
    print("Model saved to ml_models/obstacle_detector.h5")

if __name__ == "__main__":
    train()