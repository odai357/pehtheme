import cv2
import numpy as np
import pyrealsense2 as rs
import tensorflow as tf
from collections import deque
import time

class RealsenseCamera:
    def __init__(self):
        self.pipeline = rs.pipeline()
        config = rs.config()
        config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
        config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
        self.pipeline.start(config)
        self.align = rs.align(rs.stream.color)
        self.depth_scale = self.get_depth_scale()

    def get_depth_scale(self):
        profile = self.pipeline.get_active_profile()
        return profile.get_device().first_depth_sensor().get_depth_scale()

    def get_frames(self):
        frames = self.pipeline.wait_for_frames()
        aligned_frames = self.align.process(frames)
        depth_frame = aligned_frames.get_depth_frame()
        color_frame = aligned_frames.get_color_frame()
        return depth_frame, color_frame

    def release(self):
        self.pipeline.stop()

class CollisionDetector:
    def __init__(self, threshold=1.0):  # 1 meter threshold
        self.threshold = threshold
        self.ml_model = None  # Placeholder for future ML model

    def depth_based_detection(self, depth_frame, depth_scale):
        depth_image = np.asanyarray(depth_frame.get_data())
        depth_image = depth_image.astype(np.float32) * depth_scale
        
        # Create distance map and detect obstacles
        obstacle_mask = depth_image < self.threshold
        obstacle_mask = np.where(depth_image == 0, False, obstacle_mask)  # Ignore invalid
        
        return obstacle_mask, depth_image

    def load_ml_model(self, model_path):
        # Future integration point
        self.ml_model = tf.keras.models.load_model(model_path)
    
    def ml_based_detection(self, depth_data):
        # Placeholder for ML inference
        if self.ml_model:
            # Preprocess and predict
            pass
        return None

class AlertSystem:
    def __init__(self):
        self.alert_states = {"safe": (0, 255, 0), "warning": (0, 165, 255), "danger": (0, 0, 255)}
    
    def visual_alert(self, image, state, distance):
        cv2.putText(image, f"State: {state.upper()} ({distance:.2f}m", 
                   (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, self.alert_states[state], 2)
        cv2.rectangle(image, (20, 60), (120, 80), self.alert_states[state], -1)
        return image

class DataCollector:
    def __init__(self):
        self.dataset_path = "training_data/"
        self.frame_buffer = deque(maxlen=30)  # Store last 30 frames
    
    def capture_training_frame(self, depth_frame, color_frame, label):
        # Save synchronized frames with timestamp
        timestamp = time.time()
        np.save(f"{self.dataset_path}d_{timestamp}.npy", depth_frame)
        cv2.imwrite(f"{self.dataset_path}c_{timestamp}.jpg", color_frame)
        # Save label in metadata file

def main():
    # Initialize components
    camera = RealsenseCamera()
    detector = CollisionDetector(threshold=0.5)
    alert = AlertSystem()
    data_collector = DataCollector()
    
    try:
        while True:
            depth_frame, color_frame = camera.get_frames()
            color_image = np.asanyarray(color_frame.get_data())
            
            # Core detection
            obstacle_mask, depth_image = detector.depth_based_detection(
                depth_frame, camera.depth_scale
            )
            
            # Calculate min distance
            valid_depths = depth_image[depth_image > 0]
            min_distance = np.min(valid_depths) if valid_depths.size > 0 else float('inf')
            
            # Determine alert state
            state = "safe"
            if min_distance < 0.5:
                state = "danger"
            elif min_distance < detector.threshold:
                state = "warning"
            
            # Generate visual feedback
            alert_frame = alert.visual_alert(color_image.copy(), state, min_distance)
            
            # Apply obstacle visualization
            obstacle_visual = np.zeros_like(color_image)
            obstacle_visual[obstacle_mask] = (0, 0, 255)
            blended = cv2.addWeighted(alert_frame, 0.7, obstacle_visual, 0.3, 0)
            
            # Display
            cv2.imshow("Collision Avoidance", blended)
            
            # Data collection trigger (press 'c')
            key = cv2.waitKey(1)
            if key == ord('c'):
                data_collector.capture_training_frame(
                    np.asanyarray(depth_frame.get_data()), 
                    color_image, 
                    state
                )
            elif key == 27:  # ESC
                break
                
    finally:
        camera.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()