import cv2
import numpy as np
import pyrealsense2 as rs
import tensorflow as tf
from collections import deque
import time
import os

class RealsenseCamera:
    def __init__(self):
        self.pipeline = rs.pipeline()
        config = rs.config()
        config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
        config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
        self.pipeline.start(config)
        self.align = rs.align(rs.stream.color)
        self.depth_scale = self.get_depth_scale()

    def get_depth_scale(self):
        profile = self.pipeline.get_active_profile()
        return profile.get_device().first_depth_sensor().get_depth_scale()

    def get_frames(self):
        frames = self.pipeline.wait_for_frames()
        aligned_frames = self.align.process(frames)
        depth_frame = aligned_frames.get_depth_frame()
        color_frame = aligned_frames.get_color_frame()
        return depth_frame, color_frame

    def release(self):
        self.pipeline.stop()

class CollisionDetector:
    def __init__(self, threshold=1.0):
        self.threshold = threshold
        self.ml_model = None
        self.ml_enabled = False

    def load_ml_model(self, model_path):
        """Load the trained TensorFlow model."""
        try:
            self.ml_model = tf.keras.models.load_model(model_path)
            self.ml_enabled = True
            print(f"[ML] Model loaded successfully from {model_path}")
            # Warmup the model
            dummy_input = np.random.rand(1, 480, 640, 1).astype(np.float32)
            self.ml_model.predict(dummy_input)
        except Exception as e:
            print(f"[ML] Error loading model: {e}")
            self.ml_enabled = False

    def preprocess_depth(self, depth_frame, depth_scale):
        """Preprocess depth frame for both traditional and ML detection"""
        depth_image = np.asanyarray(depth_frame.get_data())
        depth_image = depth_image.astype(np.float32) * depth_scale
        depth_image[depth_image == 0] = np.nan  # Mark invalid depths
        return depth_image

    def ml_predict(self, depth_image):
        """Predict distance using the ML model."""
        if not self.ml_enabled:
            return None

        # Normalize depth for ML (match your training preprocessing)
        depth_normalized = np.clip(depth_image / 5.0, 0, 1)  # Assuming 5m max range
        depth_normalized = np.nan_to_num(depth_normalized, nan=0)  # Replace NaN with 0
        input_data = depth_normalized[np.newaxis, ..., np.newaxis]  # Add batch and channel dims

        # Predict and scale back to meters
        return self.ml_model.predict(input_data, verbose=0)[0][0] * 5.0

    def hybrid_detection(self, depth_frame, depth_scale):
        """Combine depth-based and ML detection"""
        depth_image = self.preprocess_depth(depth_frame, depth_scale)
        
        # Traditional depth analysis
        obstacle_mask = (depth_image < self.threshold) & (~np.isnan(depth_image))
        min_depth = np.nanmin(depth_image)
        
        # ML refinement for close objects
        ml_distance = None
        if self.ml_enabled and min_depth < 2.0:  # Only use ML for nearby objects
            ml_distance = self.ml_predict(depth_image)
            if ml_distance < min_depth * 0.8:  # Trust ML if significantly closer
                min_depth = ml_distance
                print(f"[ML] Refined distance: {ml_distance:.2f}m")

        return obstacle_mask, min_depth

class AlertSystem:
    def __init__(self):
        self.alert_states = {
            "safe": (0, 255, 0),
            "warning": (0, 165, 255),
            "danger": (0, 0, 255)
        }
        self.state_colors = {
            "safe": (100, 200, 100),
            "warning": (50, 150, 255),
            "danger": (100, 100, 255)
        }
    
    def visual_alert(self, image, state, distance):
        """Enhanced visualization with ML status"""
        # Main alert text
        ml_status = "(ML Active)" if state in ["warning", "danger"] else ""
        cv2.putText(image, f"{state.upper()} {ml_status}: {distance:.2f}m", 
                   (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, self.alert_states[state], 2)
        
        # Status bar
        cv2.rectangle(image, (20, 60), (int(120 * (distance/5.0)), 80), 
                     self.state_colors[state], -1)
        
        # Distance scale
        cv2.putText(image, "0m", (20, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        cv2.putText(image, "5m", (120, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        
        return image

class DataCollector:
    def __init__(self):
        self.dataset_path = "training_data/"
        os.makedirs(self.dataset_path, exist_ok=True)
        self.frame_buffer = deque(maxlen=30)
    
    def capture_training_frame(self, depth_frame, color_frame, label):
        timestamp = int(time.time() * 1000)
        depth_data = np.asanyarray(depth_frame.get_data())
        
        # Save with metadata
        np.save(f"{self.dataset_path}d_{timestamp}.npy", depth_data)
        cv2.imwrite(f"{self.dataset_path}c_{timestamp}.jpg", color_frame)
        with open(f"{self.dataset_path}m_{timestamp}.txt", "w") as f:
            f.write(f"label:{label},timestamp:{timestamp}")

def main():
    # Initialize components
    camera = RealsenseCamera()
    detector = CollisionDetector(threshold=0.8)
    alert = AlertSystem()
    data_collector = DataCollector()
    
    # Load ML model if available
    model_path = "ml_models/obstacle_detector.h5"
    if os.path.exists(model_path):
        detector.load_ml_model(model_path)
    else:
        print("[ML] No model found at", model_path)
    
    try:
        while True:
            depth_frame, color_frame = camera.get_frames()
            color_image = np.asanyarray(color_frame.get_data())
            
            # Hybrid detection
            obstacle_mask, min_distance = detector.hybrid_detection(
                depth_frame, camera.depth_scale
            )
            
            # Determine alert state
            if np.isnan(min_distance):
                state = "safe"
                min_distance = float('inf')
            else:
                state = "danger" if min_distance < 0.5 else "warning" if min_distance < detector.threshold else "safe"
            
            # Visualization
            alert_frame = alert.visual_alert(color_image.copy(), state, min_distance)
            
            # Obstacle highlighting
            if state != "safe":
                obstacle_visual = np.zeros_like(color_image)
                obstacle_visual[obstacle_mask] = (0, 0, 255)
                blended = cv2.addWeighted(alert_frame, 0.7, obstacle_visual, 0.3, 0)
            else:
                blended = alert_frame

            # Display
            cv2.imshow("Collision Avoidance", blended)
            
            # Controls
            key = cv2.waitKey(1)
            if key == ord('c'):  # Capture training data
                data_collector.capture_training_frame(
                    depth_frame, color_image, state
                )
                print(f"[Data] Captured {state} frame")
            elif key == ord('m'):  # Toggle ML
                detector.ml_enabled = not detector.ml_enabled
                print(f"[ML] {'Enabled' if detector.ml_enabled else 'Disabled'}")
            elif key == 27:  # ESC
                break
                
    finally:
        camera.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    # Hide TF logging
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
    tf.get_logger().setLevel('ERROR')
    
    main()